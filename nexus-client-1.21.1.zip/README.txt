Nexus client - Fabric 1.21.1 (Yarn mappings), Java 21

== Getting the jar (no PC needed) ==
1. Make a free GitHub repo, upload ALL files in this zip to its root (keep the .github folder).
2. Open the repo > Actions tab > "Build" > wait for the green check (2-4 min).
3. Open that run > Artifacts > download "nexus-jar" (zip) > the .jar inside is your mod.

== Getting the jar (PC) ==
gradle wrapper && ./gradlew build   -> build/libs/nexus-1.0.0.jar

== Install ==
Put nexus-1.0.0.jar + Fabric API 0.102.0+1.21.1 into the mods folder (Fabric Loader 0.16.x, Minecraft 1.21.1).
Zalith: pick Java 21, install Fabric 1.21.1, then copy both jars into that version's mods folder.

== Commands (type in chat) ==
.gui (menu, or Right Shift)   .list   .t aura   .set aura range 4.5   .set aura (show settings)   .bind aura r
Criticals works together with Aura (turn both on).

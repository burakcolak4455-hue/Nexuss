package dev.nexus.setting;

import java.util.List;

public abstract class Setting {
    public final String name;

    protected Setting(String name) { this.name = name; }

    public abstract boolean parse(String in);
    public abstract String display();

    public static class Bool extends Setting {
        public boolean value;
        public Bool(String name, boolean value) { super(name); this.value = value; }

        @Override public boolean parse(String s) {
            if (s.equalsIgnoreCase("true") || s.equalsIgnoreCase("on") || s.equals("1")) { value = true; return true; }
            if (s.equalsIgnoreCase("false") || s.equalsIgnoreCase("off") || s.equals("0")) { value = false; return true; }
            return false;
        }
        @Override public String display() { return String.valueOf(value); }
    }

    public static class Num extends Setting {
        public double value;
        public final double min, max;
        public Num(String name, double value, double min, double max) {
            super(name); this.value = value; this.min = min; this.max = max;
        }
        public float f() { return (float) value; }
        public int i() { return (int) value; }

        @Override public boolean parse(String s) {
            try {
                double d = Double.parseDouble(s);
                value = Math.max(min, Math.min(max, d));
                return true;
            } catch (NumberFormatException e) { return false; }
        }
        @Override public String display() { return value + " (" + min + "-" + max + ")"; }
    }

    public static class Mode extends Setting {
        public String value;
        public final List<String> modes;
        public Mode(String name, String value, String... modes) {
            super(name); this.value = value; this.modes = List.of(modes);
        }
        public boolean is(String m) { return value.equalsIgnoreCase(m); }

        @Override public boolean parse(String s) {
            for (String m : modes) if (m.equalsIgnoreCase(s)) { value = m; return true; }
            return false;
        }
        @Override public String display() { return value + " " + modes; }
    }
}

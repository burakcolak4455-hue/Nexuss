package dev.nexus.module;

public enum Category { COMBAT, MOVEMENT, PLAYER, RENDER, MISC }

package dev.nexus.module.modules;

import dev.nexus.module.Category;
import dev.nexus.module.Module;
import dev.nexus.setting.Setting;

/** Elytra control: fly exactly where you look, hover when not pressing forward. */
public class ElytraPlus extends Module {
    private final Setting.Num speed = add(new Setting.Num("Speed", 1.6, 0.5, 3.5));
    private final Setting.Bool hover = add(new Setting.Bool("Hover", true));

    public ElytraPlus() { super("ElytraPlus", Category.MOVEMENT); }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || !p.isFallFlying()) return;
        if (p.input.movementForward > 0) p.setVelocity(p.getRotationVec(1f).multiply(speed.value));
        else if (hover.value) p.setVelocity(0, 0, 0);
    }
}

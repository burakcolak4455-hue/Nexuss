package dev.nexus.module.modules;

import dev.nexus.module.Category;
import dev.nexus.module.Module;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Tells you in chat when a player enters or leaves your render range. */
public class VisualRange extends Module {
    private final Map<UUID, String> known = new HashMap<>();

    public VisualRange() { super("VisualRange", Category.MISC); }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        Map<UUID, String> now = new HashMap<>();
        for (PlayerEntity pl : mc.world.getPlayers())
            if (pl != mc.player) now.put(pl.getUuid(), pl.getName().getString());

        now.forEach((id, n) -> { if (!known.containsKey(id)) msg("§a" + n + " entered range"); });
        known.forEach((id, n) -> { if (!now.containsKey(id)) msg("§c" + n + " left range"); });
        known.clear();
        known.putAll(now);
    }

    @Override
    public void onEnable() { known.clear(); }

    private void msg(String s) {
        if (mc.player != null) mc.player.sendMessage(Text.literal("§8[§bVisualRange§8] §r" + s), false);
    }
}

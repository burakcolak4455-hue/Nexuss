package dev.nexus.module.modules;

import dev.nexus.module.Category;
import dev.nexus.module.Module;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;

/** Re-opens the elytra automatically when you fall while wearing one. */
public class ElytraRecast extends Module {
    public ElytraRecast() { super("ElytraRecast", Category.MOVEMENT); }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || p.isFallFlying() || p.isOnGround() || p.isTouchingWater() || p.isInLava()) return;
        if (!p.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA)) return;
        if (p.getVelocity().y >= 0 || p.fallDistance < 0.5f) return;
        p.networkHandler.sendPacket(new ClientCommandC2SPacket(p, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
        p.startFallFlying();
    }
}

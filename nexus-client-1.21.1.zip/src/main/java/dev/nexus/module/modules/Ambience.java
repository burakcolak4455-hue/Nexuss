package dev.nexus.module.modules;

import dev.nexus.module.Category;
import dev.nexus.module.Module;
import dev.nexus.setting.Setting;

/** Client-side time of day (0 = sunrise, 6000 = noon, 13000 = night). */
public class Ambience extends Module {
    private final Setting.Num time = add(new Setting.Num("Time", 6000, 0, 24000));

    public Ambience() { super("Ambience", Category.RENDER); }

    @Override
    public void onTick() {
        if (mc.world != null) mc.world.setTimeOfDay(time.i());
    }
}

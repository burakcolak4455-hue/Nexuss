package dev.nexus.module.modules;

import dev.nexus.module.Category;
import dev.nexus.module.Module;
import dev.nexus.setting.Setting;
import dev.nexus.util.InvUtil;
import dev.nexus.util.PlaceUtil;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

public class AutoTrap extends Module {
    private final Setting.Num range   = add(new Setting.Num("Range", 5.0, 2.0, 6.0));
    private final Setting.Num perTick = add(new Setting.Num("BlocksPerTick", 2, 1, 5));
    private final Setting.Bool top    = add(new Setting.Bool("Top", true));

    public AutoTrap() { super("AutoTrap", Category.COMBAT); }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        int slot = InvUtil.findHotbar(Items.OBSIDIAN);
        if (slot < 0) return;
        PlayerEntity t = PlaceUtil.nearestPlayer(range.value);
        if (t == null) return;

        BlockPos feet = t.getBlockPos();
        int placed = 0;
        for (Direction d : Direction.Type.HORIZONTAL) {
            if (placed >= perTick.i()) return;
            if (PlaceUtil.place(feet.offset(d), slot)) placed++;
            if (placed >= perTick.i()) return;
            if (PlaceUtil.place(feet.up().offset(d), slot)) placed++;
        }
        if (top.value && placed < perTick.i()) PlaceUtil.place(feet.up(2), slot);
    }
}

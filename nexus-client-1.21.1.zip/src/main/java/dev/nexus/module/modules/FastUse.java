package dev.nexus.module.modules;

import dev.nexus.module.Category;
import dev.nexus.module.Module;

public class FastUse extends Module {
    public FastUse() { super("FastUse", Category.PLAYER); }

    @Override
    public void onTick() { mc.itemUseCooldown = 0; }
}

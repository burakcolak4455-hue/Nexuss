package dev.nexus.module.modules;

import dev.nexus.module.Category;
import dev.nexus.module.Module;
import dev.nexus.setting.Setting;
import net.minecraft.util.math.Vec3d;

public class ElytraBooster extends Module {
    private final Setting.Num accel    = add(new Setting.Num("Accel", 0.04, 0.005, 0.2));
    private final Setting.Num maxSpeed = add(new Setting.Num("MaxSpeed", 2.0, 0.5, 4.0));

    public ElytraBooster() { super("ElytraBooster", Category.MOVEMENT); }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || !p.isFallFlying() || p.input.movementForward <= 0) return;
        Vec3d v = p.getVelocity();
        if (v.length() >= maxSpeed.value) return;
        p.setVelocity(v.add(p.getRotationVec(1f).multiply(accel.value)));
    }
}

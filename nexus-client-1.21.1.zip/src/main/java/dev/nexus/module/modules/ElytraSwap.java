package dev.nexus.module.modules;

import dev.nexus.module.Category;
import dev.nexus.module.Module;
import dev.nexus.util.InvUtil;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

/** One-shot: swaps chestplate <-> elytra, then turns itself off. */
public class ElytraSwap extends Module {
    public ElytraSwap() { super("ElytraSwap", Category.PLAYER); }

    @Override
    public void onEnable() {
        var p = mc.player;
        if (p == null) { setEnabled(false); return; }

        boolean wearingElytra = p.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA);
        int idx = -1;
        for (int i = 0; i < 36; i++) {
            var s = p.getInventory().getStack(i);
            boolean match = wearingElytra
                ? (s.getItem() instanceof ArmorItem a && a.getSlotType() == EquipmentSlot.CHEST)
                : s.isOf(Items.ELYTRA);
            if (match) { idx = i; break; }
        }
        if (idx >= 0) {
            int slot = InvUtil.toScreenSlot(idx), id = p.playerScreenHandler.syncId;
            mc.interactionManager.clickSlot(id, slot, 0, SlotActionType.PICKUP, p);
            mc.interactionManager.clickSlot(id, 6, 0, SlotActionType.PICKUP, p);
            mc.interactionManager.clickSlot(id, slot, 0, SlotActionType.PICKUP, p);
        }
        setEnabled(false);
    }
}

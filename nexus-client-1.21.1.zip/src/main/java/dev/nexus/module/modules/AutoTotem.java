package dev.nexus.module.modules;

import dev.nexus.module.Category;
import dev.nexus.module.Module;
import dev.nexus.setting.Setting;
import dev.nexus.util.InvUtil;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public class AutoTotem extends Module {
    private final Setting.Num health = add(new Setting.Num("Health", 20, 1, 20));
    private final Setting.Num delay  = add(new Setting.Num("Delay", 3, 0, 20));
    private int wait;

    public AutoTotem() { super("AutoTotem", Category.COMBAT); }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.currentScreen != null) return;
        if (wait > 0) { wait--; return; }
        if (p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
        if (p.getHealth() > health.value) return;

        int idx = InvUtil.findInventory(Items.TOTEM_OF_UNDYING);
        if (idx < 0) return;
        mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, InvUtil.toScreenSlot(idx), 40, SlotActionType.SWAP, p);
        wait = delay.i();
    }
}

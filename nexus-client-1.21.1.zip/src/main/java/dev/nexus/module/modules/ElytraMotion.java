package dev.nexus.module.modules;

import dev.nexus.module.Category;
import dev.nexus.module.Module;
import dev.nexus.setting.Setting;

/** Vertical control while gliding: jump = up, sneak = down, otherwise hold height. */
public class ElytraMotion extends Module {
    private final Setting.Num vertical = add(new Setting.Num("Vertical", 0.6, 0.1, 2.0));

    public ElytraMotion() { super("ElytraMotion", Category.MOVEMENT); }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || !p.isFallFlying()) return;
        double y = 0;
        if (mc.options.jumpKey.isPressed()) y = vertical.value;
        else if (mc.options.sneakKey.isPressed()) y = -vertical.value;
        p.setVelocity(p.getVelocity().x, y, p.getVelocity().z);
    }
}

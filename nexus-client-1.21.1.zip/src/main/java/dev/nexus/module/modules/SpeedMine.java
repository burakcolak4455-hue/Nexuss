package dev.nexus.module.modules;

import dev.nexus.module.Category;
import dev.nexus.module.Module;
import dev.nexus.setting.Setting;

public class SpeedMine extends Module {
    private final Setting.Num boost = add(new Setting.Num("Boost", 0.1, 0.0, 0.5));

    public SpeedMine() { super("SpeedMine", Category.PLAYER); }

    @Override
    public void onTick() {
        var im = mc.interactionManager;
        if (im == null) return;
        im.blockBreakingCooldown = 0;
        if (im.currentBreakingProgress > 0f) im.currentBreakingProgress = Math.min(0.99f, im.currentBreakingProgress + boost.f());
    }
}

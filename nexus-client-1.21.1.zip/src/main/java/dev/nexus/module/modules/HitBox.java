package dev.nexus.module.modules;

import dev.nexus.module.Category;
import dev.nexus.module.Module;
import dev.nexus.setting.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

public class HitBox extends Module {
    private final Setting.Num expand = add(new Setting.Num("Expand", 0.3, 0.0, 1.5));
    private final Setting.Bool onlyPlayers = add(new Setting.Bool("OnlyPlayers", true));

    public HitBox() { super("HitBox", Category.COMBAT); }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        for (Entity e : mc.world.getEntities()) {
            if (e == mc.player || !(e instanceof LivingEntity)) continue;
            if (onlyPlayers.value && !(e instanceof PlayerEntity)) continue;
            e.setBoundingBox(e.getDimensions(e.getPose()).getBoxAt(e.getPos()).expand(expand.value, 0, expand.value));
        }
    }
}

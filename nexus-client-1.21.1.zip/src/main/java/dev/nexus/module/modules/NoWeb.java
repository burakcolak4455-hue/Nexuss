package dev.nexus.module.modules;

import dev.nexus.module.Category;
import dev.nexus.module.Module;
import net.minecraft.util.math.Vec3d;

public class NoWeb extends Module {
    public NoWeb() { super("NoWeb", Category.PLAYER); }

    @Override
    public void onTick() {
        if (mc.player != null) mc.player.movementMultiplier = Vec3d.ZERO;
    }
}

package dev.nexus.module.modules;

import dev.nexus.module.Category;
import dev.nexus.module.Module;
import dev.nexus.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

/** Used by Aura: sends small fake-jump packets right before an attack so it counts as a critical. */
public class Criticals extends Module {
    public Criticals() { super("Criticals", Category.COMBAT); }

    public static void apply() {
        if (!(ModuleManager.get("Criticals") instanceof Criticals c) || !c.isEnabled()) return;
        var p = MinecraftClient.getInstance().player;
        if (p == null || !p.isOnGround() || p.isTouchingWater() || p.isInLava() || p.isClimbing()) return;
        double x = p.getX(), y = p.getY(), z = p.getZ();
        p.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(x, y + 0.0625, z, false));
        p.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(x, y, z, false));
    }
}

package dev.nexus.module.modules;

import dev.nexus.module.Category;
import dev.nexus.module.Module;
import dev.nexus.setting.Setting;
import dev.nexus.util.RotationUtil;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Locks onto a target and never lets go until the module is turned off (or the target dies / unloads).
 * Flies a lead-intercept course that passes in FRONT of the target, and attacks the moment it is in reach.
 */
public class ElytraTarget extends Module {
    private final Setting.Num range        = add(new Setting.Num("Range", 64, 8, 128));
    private final Setting.Num turnSpeed    = add(new Setting.Num("TurnSpeed", 40, 5, 180));
    private final Setting.Num predict      = add(new Setting.Num("Predict", 1.0, 0.0, 3.0));
    private final Setting.Num front        = add(new Setting.Num("Front", 2.0, 0.0, 6.0));
    private final Setting.Num reach        = add(new Setting.Num("Reach", 4.0, 2.5, 5.5));
    private final Setting.Num cooldown     = add(new Setting.Num("Cooldown", 0.9, 0.0, 1.0));
    private final Setting.Bool ignoreCd    = add(new Setting.Bool("IgnoreCooldown", false));
    private final Setting.Bool fireworks   = add(new Setting.Bool("AutoFirework", true));
    private final Setting.Num minSpeed     = add(new Setting.Num("MinSpeed", 1.4, 0.5, 3.0));
    private final Setting.Num boostDelay   = add(new Setting.Num("BoostDelay", 15, 5, 100));
    private final Setting.Bool autoRecast  = add(new Setting.Bool("AutoRecast", true));
    private final Setting.Bool onlyPlayers = add(new Setting.Bool("OnlyPlayers", true));

    private Entity locked;
    private int boostTimer;

    public ElytraTarget() { super("ElytraTarget", Category.MOVEMENT); }

    @Override public void onEnable()  { locked = null; boostTimer = 0; }
    @Override public void onDisable() { locked = null; }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) return;
        if (boostTimer > 0) boostTimer--;

        // Keep the same target for good. Only re-pick if it died or unloaded.
        if (locked == null || !locked.isAlive() || locked.isRemoved() || locked.getWorld() != mc.world) {
            locked = findTarget(p);
            if (locked != null) msg("Locked on §f" + locked.getName().getString());
        }
        if (locked == null) return;

        if (!p.isFallFlying()) {
            if (autoRecast.value) recast(p);
            return;
        }

        Vec3d eye = p.getEyePos();
        Vec3d tPos = locked.getPos();
        double dist = eye.distanceTo(tPos);
        double mySpeed = p.getVelocity().length();

        // Target movement and heading
        Vec3d tVel = tPos.subtract(new Vec3d(locked.prevX, locked.prevY, locked.prevZ));
        Vec3d flat = new Vec3d(tVel.x, 0, tVel.z);
        Vec3d heading = flat.length() > 0.05 ? flat.normalize() : Vec3d.fromPolar(0, locked.getYaw());

        // Lead the target, then aim a bit AHEAD of it so we cross in front of it.
        double ticksAhead = (dist / Math.max(0.8, mySpeed)) * predict.value;
        double f = front.value * MathHelper.clamp((dist - 2.0) / 6.0, 0.0, 1.0);
        Vec3d aim = tPos.add(0, locked.getHeight() * 0.5, 0)
                        .add(tVel.multiply(ticksAhead))
                        .add(heading.multiply(f));

        float[] rot = RotationUtil.rotationsTo(eye, aim);
        RotationUtil.turn(p, rot[0], rot[1], turnSpeed.f());

        // Hit as soon as we're in reach now OR will be next tick (we're fast, so check both).
        Box b = locked.getBoundingBox();
        double d = Math.min(nearest(eye, b), nearest(eye.add(p.getVelocity()), b));
        if (d <= reach.value && (ignoreCd.value || p.getAttackCooldownProgress(0.5f) >= cooldown.value)) {
            mc.interactionManager.attackEntity(p, locked);
            p.swingHand(Hand.MAIN_HAND);
        }

        if (fireworks.value && boostTimer == 0 && mySpeed < minSpeed.value && dist > 3.0) {
            if (useFirework(p)) boostTimer = boostDelay.i();
        }
    }

    private double nearest(Vec3d from, Box b) {
        Vec3d n = new Vec3d(
            MathHelper.clamp(from.x, b.minX, b.maxX),
            MathHelper.clamp(from.y, b.minY, b.maxY),
            MathHelper.clamp(from.z, b.minZ, b.maxZ));
        return from.distanceTo(n);
    }

    private Entity findTarget(ClientPlayerEntity p) {
        Entity best = null;
        double bestDist = range.value;
        for (Entity e : mc.world.getEntities()) {
            if (e == p || !e.isAlive() || !(e instanceof LivingEntity)) continue;
            if (onlyPlayers.value && !(e instanceof PlayerEntity pl && !pl.isSpectator())) continue;
            double d = p.getPos().distanceTo(e.getPos());
            if (d < bestDist) { bestDist = d; best = e; }
        }
        return best;
    }

    private void recast(ClientPlayerEntity p) {
        if (p.isOnGround() || p.isTouchingWater() || p.isInLava()) return;
        if (!p.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA)) return;
        if (p.getVelocity().y >= 0) return;
        p.networkHandler.sendPacket(new ClientCommandC2SPacket(p, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
        p.startFallFlying();
    }

    private boolean useFirework(ClientPlayerEntity p) {
        if (p.getOffHandStack().isOf(Items.FIREWORK_ROCKET)) {
            mc.interactionManager.interactItem(p, Hand.OFF_HAND);
            return true;
        }
        for (int i = 0; i < 9; i++) {
            if (p.getInventory().getStack(i).isOf(Items.FIREWORK_ROCKET)) {
                int prev = p.getInventory().selectedSlot;
                p.getInventory().selectedSlot = i;
                mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
                p.getInventory().selectedSlot = prev;
                return true;
            }
        }
        return false;
    }

    private void msg(String s) {
        if (mc.player != null) mc.player.sendMessage(Text.literal("§8[§bElytraTarget§8] §r" + s), false);
    }
}

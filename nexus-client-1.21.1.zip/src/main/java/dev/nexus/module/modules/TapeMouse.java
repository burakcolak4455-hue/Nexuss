package dev.nexus.module.modules;

import dev.nexus.module.Category;
import dev.nexus.module.Module;
import dev.nexus.setting.Setting;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;

/** Auto-clicker. */
public class TapeMouse extends Module {
    private final Setting.Mode mode = add(new Setting.Mode("Mode", "Attack", "Attack", "Use"));
    private final Setting.Num delay = add(new Setting.Num("Delay", 10, 1, 40));
    private int t;

    public TapeMouse() { super("TapeMouse", Category.MISC); }

    @Override
    public void onTick() {
        if (mc.player == null || mc.currentScreen != null) return;
        if (++t < delay.i()) return;
        t = 0;
        KeyBinding kb = mode.is("Use") ? mc.options.useKey : mc.options.attackKey;
        KeyBinding.onKeyPressed(InputUtil.fromTranslationKey(kb.getBoundKeyTranslationKey()));
    }
}

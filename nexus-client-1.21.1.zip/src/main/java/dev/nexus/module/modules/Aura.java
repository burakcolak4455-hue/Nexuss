package dev.nexus.module.modules;

import dev.nexus.module.Category;
import dev.nexus.module.Module;
import dev.nexus.setting.Setting;
import dev.nexus.util.RotationUtil;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class Aura extends Module {
    private final Setting.Num range     = add(new Setting.Num("Range", 3.0, 1.0, 6.0));
    private final Setting.Num cooldown  = add(new Setting.Num("Cooldown", 0.92, 0.0, 1.0));
    private final Setting.Num fov       = add(new Setting.Num("FOV", 360, 30, 360));
    private final Setting.Mode sort     = add(new Setting.Mode("Sort", "Distance", "Distance", "Health", "Angle"));
    private final Setting.Bool players  = add(new Setting.Bool("Players", true));
    private final Setting.Bool hostiles = add(new Setting.Bool("Hostiles", true));
    private final Setting.Bool passives = add(new Setting.Bool("Passives", false));
    private final Setting.Bool walls    = add(new Setting.Bool("Walls", false));
    private final Setting.Bool rotate   = add(new Setting.Bool("Rotate", true));
    private final Setting.Num turnSpeed = add(new Setting.Num("TurnSpeed", 35, 5, 180));

    public static LivingEntity target;

    public Aura() { super("Aura", Category.COMBAT); }

    @Override
    public void onDisable() { target = null; }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.currentScreen != null || p.isSpectator()) return;

        LivingEntity t = findTarget(p);
        target = t;
        if (t == null) return;

        Vec3d eye = p.getEyePos();
        float[] rot = RotationUtil.rotationsTo(eye, t.getBoundingBox().getCenter());

        if (rotate.value) {
            RotationUtil.turn(p, rot[0], rot[1], turnSpeed.f());
            // Wait until we're actually facing the target before swinging.
            if (RotationUtil.angleDiff(p, rot[0], rot[1]) > 25f) return;
        }

        if (p.getAttackCooldownProgress(0.5f) < cooldown.value) return;

        Criticals.apply();
        mc.interactionManager.attackEntity(p, t);
        p.swingHand(Hand.MAIN_HAND);
    }

    private LivingEntity findTarget(ClientPlayerEntity p) {
        Vec3d eye = p.getEyePos();
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;

        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || le instanceof ArmorStandEntity) continue;

            if (le instanceof PlayerEntity pl) {
                if (!players.value || pl.isSpectator()) continue;
            } else if (le instanceof HostileEntity) {
                if (!hostiles.value) continue;
            } else if (!passives.value) continue;

            Box b = le.getBoundingBox();
            Vec3d near = new Vec3d(
                MathHelper.clamp(eye.x, b.minX, b.maxX),
                MathHelper.clamp(eye.y, b.minY, b.maxY),
                MathHelper.clamp(eye.z, b.minZ, b.maxZ));
            double dist = eye.distanceTo(near);
            if (dist > range.value) continue;
            if (!walls.value && !p.canSee(le)) continue;

            float[] rot = RotationUtil.rotationsTo(eye, b.getCenter());
            float diff = RotationUtil.angleDiff(p, rot[0], rot[1]);
            if (diff > fov.value / 2.0) continue;

            double score = switch (sort.value) {
                case "Health" -> le.getHealth();
                case "Angle" -> diff;
                default -> dist;
            };
            if (score < bestScore) { bestScore = score; best = le; }
        }
        return best;
    }
}

package dev.nexus.module.modules;

import dev.nexus.module.Category;
import dev.nexus.module.Module;
import dev.nexus.setting.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;

/** Outline ESP using the vanilla glow effect (client-side only). */
public class ESP extends Module {
    private final Setting.Bool players  = add(new Setting.Bool("Players", true));
    private final Setting.Bool hostiles = add(new Setting.Bool("Hostiles", false));
    private final Setting.Bool passives = add(new Setting.Bool("Passives", false));

    public ESP() { super("ESP", Category.RENDER); }

    @Override
    public void onTick() {
        if (mc.world == null) return;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity) || e == mc.player) continue;
            boolean want = e instanceof PlayerEntity ? players.value
                         : e instanceof HostileEntity ? hostiles.value : passives.value;
            if (e.isGlowing() != want) e.setGlowing(want);
        }
    }

    @Override
    public void onDisable() {
        if (mc.world == null) return;
        for (Entity e : mc.world.getEntities()) if (e instanceof LivingEntity) e.setGlowing(false);
    }
}

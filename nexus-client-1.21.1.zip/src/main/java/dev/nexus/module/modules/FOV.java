package dev.nexus.module.modules;

import dev.nexus.module.Category;
import dev.nexus.module.Module;
import dev.nexus.setting.Setting;

public class FOV extends Module {
    private final Setting.Num fov = add(new Setting.Num("FOV", 100, 30, 110));
    private int original = 70;

    public FOV() { super("FOV", Category.RENDER); }

    @Override public void onEnable() { original = mc.options.getFov().getValue(); }
    @Override public void onTick() { mc.options.getFov().setValue(fov.i()); }
    @Override public void onDisable() { mc.options.getFov().setValue(original); }
}

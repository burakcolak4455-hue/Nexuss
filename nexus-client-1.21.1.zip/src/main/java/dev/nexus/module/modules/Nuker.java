package dev.nexus.module.modules;

import dev.nexus.module.Category;
import dev.nexus.module.Module;
import dev.nexus.setting.Setting;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

public class Nuker extends Module {
    private final Setting.Num radius = add(new Setting.Num("Radius", 4, 1, 6));

    public Nuker() { super("Nuker", Category.MISC); }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null || mc.currentScreen != null) return;

        int r = radius.i();
        BlockPos base = p.getBlockPos();
        BlockPos best = null;
        double bd = Double.MAX_VALUE;
        for (int x = -r; x <= r; x++)
            for (int y = -r; y <= r; y++)
                for (int z = -r; z <= r; z++) {
                    BlockPos pos = base.add(x, y, z);
                    var st = mc.world.getBlockState(pos);
                    if (st.isAir() || !st.getFluidState().isEmpty() || st.getHardness(mc.world, pos) < 0) continue;
                    double d = p.getEyePos().distanceTo(pos.toCenterPos());
                    if (d > radius.value || d >= bd) continue;
                    bd = d; best = pos;
                }
        if (best == null) return;
        mc.interactionManager.updateBlockBreakingProgress(best, Direction.UP);
        p.swingHand(Hand.MAIN_HAND);
    }
}

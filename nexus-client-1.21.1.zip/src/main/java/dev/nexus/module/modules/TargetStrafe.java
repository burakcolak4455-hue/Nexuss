package dev.nexus.module.modules;

import dev.nexus.module.Category;
import dev.nexus.module.Module;
import dev.nexus.setting.Setting;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;

/** Circles around the current Aura target. */
public class TargetStrafe extends Module {
    private final Setting.Num radius = add(new Setting.Num("Radius", 2.5, 1.0, 5.0));
    private final Setting.Num speed  = add(new Setting.Num("Speed", 0.26, 0.1, 0.6));
    private final Setting.Bool jump  = add(new Setting.Bool("Jump", true));
    private int dir = 1;

    public TargetStrafe() { super("TargetStrafe", Category.MOVEMENT); }

    @Override
    public void onTick() {
        var p = mc.player;
        LivingEntity t = Aura.target;
        if (p == null || t == null || p.isFallFlying()) return;

        Vec3d tp = t.getPos();
        double ang = Math.atan2(p.getZ() - tp.z, p.getX() - tp.x);
        if (p.horizontalCollision) dir = -dir;
        ang += dir * speed.value / radius.value;

        double nx = tp.x + Math.cos(ang) * radius.value;
        double nz = tp.z + Math.sin(ang) * radius.value;
        Vec3d v = new Vec3d(nx - p.getX(), 0, nz - p.getZ());
        if (v.length() > speed.value) v = v.normalize().multiply(speed.value);
        p.setVelocity(v.x, p.getVelocity().y, v.z);
        if (jump.value && p.isOnGround()) p.jump();
    }
}

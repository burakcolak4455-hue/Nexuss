package dev.nexus.module.modules;

import dev.nexus.module.Category;
import dev.nexus.module.Module;

public class Sprint extends Module {
    public Sprint() { super("Sprint", Category.MOVEMENT); }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null) return;
        if (p.input.movementForward > 0 && !p.horizontalCollision && !p.isSneaking()
                && p.getHungerManager().getFoodLevel() > 6) {
            p.setSprinting(true);
        }
    }
}

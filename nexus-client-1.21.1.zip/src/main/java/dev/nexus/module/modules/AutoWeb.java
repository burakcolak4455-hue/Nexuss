package dev.nexus.module.modules;

import dev.nexus.module.Category;
import dev.nexus.module.Module;
import dev.nexus.setting.Setting;
import dev.nexus.util.InvUtil;
import dev.nexus.util.PlaceUtil;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;

public class AutoWeb extends Module {
    private final Setting.Num range = add(new Setting.Num("Range", 5.0, 2.0, 6.0));

    public AutoWeb() { super("AutoWeb", Category.COMBAT); }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        int slot = InvUtil.findHotbar(Items.COBWEB);
        if (slot < 0) return;
        PlayerEntity t = PlaceUtil.nearestPlayer(range.value);
        if (t == null) return;
        BlockPos feet = t.getBlockPos();
        if (!PlaceUtil.place(feet, slot)) PlaceUtil.place(feet.up(), slot);
    }
}

package dev.nexus.module.modules;

import dev.nexus.module.Category;
import dev.nexus.module.Module;
import dev.nexus.setting.Setting;
import dev.nexus.util.InvUtil;
import net.minecraft.item.Items;

public class AutoGApple extends Module {
    private final Setting.Num health = add(new Setting.Num("Health", 10, 1, 20));
    private boolean eating;
    private int prevSlot = -1, eatTicks, cooldown;

    public AutoGApple() { super("AutoGApple", Category.COMBAT); }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.currentScreen != null) return;

        if (eating) {
            eatTicks++;
            if (!p.isUsingItem() && eatTicks > 3) finish();
            else mc.options.useKey.setPressed(true);
            return;
        }
        if (cooldown > 0) { cooldown--; return; }
        if (p.getHealth() > health.value) return;

        int slot = InvUtil.findHotbar(Items.ENCHANTED_GOLDEN_APPLE);
        if (slot < 0) slot = InvUtil.findHotbar(Items.GOLDEN_APPLE);
        if (slot < 0) return;

        prevSlot = p.getInventory().selectedSlot;
        p.getInventory().selectedSlot = slot;
        mc.options.useKey.setPressed(true);
        eating = true;
        eatTicks = 0;
    }

    private void finish() {
        mc.options.useKey.setPressed(false);
        if (mc.player != null && prevSlot >= 0) mc.player.getInventory().selectedSlot = prevSlot;
        prevSlot = -1;
        eating = false;
        cooldown = 10;
    }

    @Override
    public void onDisable() { if (eating) finish(); }
}

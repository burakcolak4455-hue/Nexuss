package dev.nexus.module;

import dev.nexus.module.modules.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    public static final List<Module> modules = new ArrayList<>();

    public static void init() {
        // combat
        modules.add(new Aura());
        modules.add(new Criticals());
        modules.add(new HitBox());
        modules.add(new AutoTotem());
        modules.add(new AutoGApple());
        modules.add(new AutoTrap());
        modules.add(new AutoWeb());
        // movement
        modules.add(new ElytraTarget());
        modules.add(new ElytraBooster());
        modules.add(new ElytraPlus());
        modules.add(new ElytraMotion());
        modules.add(new ElytraRecast());
        modules.add(new TargetStrafe());
        modules.add(new Sprint());
        // player
        modules.add(new ElytraSwap());
        modules.add(new FastUse());
        modules.add(new SpeedMine());
        modules.add(new NoWeb());
        // render
        modules.add(new Fullbright());
        modules.add(new ESP());
        modules.add(new FOV());
        modules.add(new Ambience());
        // misc
        modules.add(new Nuker());
        modules.add(new TapeMouse());
        modules.add(new VisualRange());
    }

    public static Module get(String name) {
        for (Module m : modules) if (m.name.equalsIgnoreCase(name)) return m;
        return null;
    }

    public static void tick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;

        for (Module m : modules) {
            // Key binds (only when no screen is open)
            if (m.key != -1 && mc.currentScreen == null) {
                boolean down = InputUtil.isKeyPressed(mc.getWindow().getHandle(), m.key);
                if (down && !m.wasDown) m.toggle();
                m.wasDown = down;
            }
            if (m.isEnabled()) m.onTick();
        }
    }
}

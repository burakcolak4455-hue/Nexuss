package dev.nexus.util;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class RotationUtil {
    /** Returns {yaw, pitch} needed to look from one point to another. */
    public static float[] rotationsTo(Vec3d from, Vec3d to) {
        double dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
        double flat = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, flat));
        return new float[]{yaw, MathHelper.clamp(pitch, -90f, 90f)};
    }

    /** Total angular distance between the player's view and a target rotation. */
    public static float angleDiff(ClientPlayerEntity p, float yaw, float pitch) {
        float dy = MathHelper.wrapDegrees(yaw - p.getYaw());
        float dp = pitch - p.getPitch();
        return (float) Math.sqrt(dy * dy + dp * dp);
    }

    /** Turns the player's view toward a rotation by at most maxStep degrees per axis. */
    public static void turn(ClientPlayerEntity p, float yaw, float pitch, float maxStep) {
        float dy = MathHelper.clamp(MathHelper.wrapDegrees(yaw - p.getYaw()), -maxStep, maxStep);
        float dp = MathHelper.clamp(pitch - p.getPitch(), -maxStep, maxStep);
        p.setYaw(p.getYaw() + dy);
        p.setPitch(MathHelper.clamp(p.getPitch() + dp, -90f, 90f));
    }
}

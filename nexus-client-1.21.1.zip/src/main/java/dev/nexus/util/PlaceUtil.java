package dev.nexus.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public class PlaceUtil {
    /** Places the held hotbar item at pos by clicking an adjacent solid block. */
    public static boolean place(BlockPos pos, int hotbarSlot) {
        MinecraftClient mc = MinecraftClient.getInstance();
        var p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) return false;
        if (!mc.world.getBlockState(pos).isReplaceable()) return false;

        for (Direction d : Direction.values()) {
            BlockPos n = pos.offset(d);
            var st = mc.world.getBlockState(n);
            if (st.isAir() || st.isReplaceable() || !st.getFluidState().isEmpty()) continue;

            Direction face = d.getOpposite();
            Vec3d hit = Vec3d.ofCenter(n).add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);
            int prev = p.getInventory().selectedSlot;
            p.getInventory().selectedSlot = hotbarSlot;
            mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, new BlockHitResult(hit, face, n, false));
            p.swingHand(Hand.MAIN_HAND);
            p.getInventory().selectedSlot = prev;
            return true;
        }
        return false;
    }

    public static PlayerEntity nearestPlayer(double range) {
        MinecraftClient mc = MinecraftClient.getInstance();
        PlayerEntity best = null;
        double bd = range;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof PlayerEntity pl) || pl == mc.player || !pl.isAlive() || pl.isSpectator()) continue;
            double d = mc.player.distanceTo(pl);
            if (d < bd) { bd = d; best = pl; }
        }
        return best;
    }
}

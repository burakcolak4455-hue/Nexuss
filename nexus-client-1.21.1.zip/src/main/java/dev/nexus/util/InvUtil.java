package dev.nexus.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Item;

public class InvUtil {
    /** Hotbar slot (0-8) holding the item, or -1. */
    public static int findHotbar(Item item) {
        var p = MinecraftClient.getInstance().player;
        if (p == null) return -1;
        for (int i = 0; i < 9; i++) if (p.getInventory().getStack(i).isOf(item)) return i;
        return -1;
    }

    /** Inventory index (0-35, hotbar first) holding the item, or -1. */
    public static int findInventory(Item item) {
        var p = MinecraftClient.getInstance().player;
        if (p == null) return -1;
        for (int i = 0; i < 36; i++) if (p.getInventory().getStack(i).isOf(item)) return i;
        return -1;
    }

    /** Converts a player inventory index into a PlayerScreenHandler slot id. */
    public static int toScreenSlot(int invIndex) {
        return invIndex < 9 ? invIndex + 36 : invIndex;
    }
}

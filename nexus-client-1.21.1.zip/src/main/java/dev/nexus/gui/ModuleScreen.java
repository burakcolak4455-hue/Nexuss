package dev.nexus.gui;

import dev.nexus.module.Category;
import dev.nexus.module.Module;
import dev.nexus.module.ModuleManager;
import dev.nexus.setting.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.List;

/** Touch-friendly menu: tap a module to toggle it, tap the arrow next to it for its settings. */
public class ModuleScreen extends Screen {
    private Category cat = Category.COMBAT;
    private Module open;

    public ModuleScreen() { super(Text.literal("Nexus")); }

    @Override protected void init() { rebuild(); }
    @Override public boolean shouldPause() { return false; }

    private void rebuild() {
        clearChildren();
        if (open == null) buildList(); else buildSettings();
    }

    private void buildList() {
        Category[] cs = Category.values();
        int tw = Math.min(90, (width - 20) / cs.length);
        int tx = (width - tw * cs.length) / 2;
        for (int i = 0; i < cs.length; i++) {
            final Category c = cs[i];
            String name = c.name().charAt(0) + c.name().substring(1).toLowerCase();
            Text label = Text.literal((c == cat ? "§b" : "§7") + name);
            addDrawableChild(ButtonWidget.builder(label, b -> { cat = c; rebuild(); })
                .dimensions(tx + i * tw, 22, tw - 2, 18).build());
        }

        List<Module> ms = ModuleManager.modules.stream().filter(m -> m.category == cat).toList();
        int cols = 2, cw = 120, gw = 20, gap = 8;
        int x0 = (width - (cols * (cw + gw) + (cols - 1) * gap)) / 2;
        for (int i = 0; i < ms.size(); i++) {
            final Module m = ms.get(i);
            int x = x0 + (i % cols) * (cw + gw + gap);
            int y = 48 + (i / cols) * 22;
            Text label = Text.literal((m.isEnabled() ? "§a" : "§c") + m.name);
            addDrawableChild(ButtonWidget.builder(label, b -> { m.toggle(); rebuild(); })
                .dimensions(x, y, cw, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal(">"), b -> { open = m; rebuild(); })
                .dimensions(x + cw, y, gw, 20).build());
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> close())
            .dimensions(width / 2 - 40, height - 26, 80, 20).build());
    }

    private void buildSettings() {
        int cols = 2, lw = 130, sw = 18, gap = 10;
        int x0 = (width - (cols * (lw + sw * 2 + 4) + (cols - 1) * gap)) / 2;
        for (int i = 0; i < open.settings.size(); i++) {
            final Setting s = open.settings.get(i);
            int x = x0 + (i % cols) * (lw + sw * 2 + 4 + gap);
            int y = 36 + (i / cols) * 22;
            Text label = Text.literal("§f" + s.name + ": §b" + value(s));

            if (s instanceof Setting.Bool bs) {
                addDrawableChild(ButtonWidget.builder(label, b -> { bs.value = !bs.value; rebuild(); })
                    .dimensions(x, y, lw, 20).build());
            } else if (s instanceof Setting.Mode ms) {
                addDrawableChild(ButtonWidget.builder(label, b -> {
                    int idx = ms.modes.indexOf(ms.value);
                    ms.value = ms.modes.get((idx + 1) % ms.modes.size());
                    rebuild();
                }).dimensions(x, y, lw, 20).build());
            } else if (s instanceof Setting.Num ns) {
                double step = Math.max(0.01, (ns.max - ns.min) / 20.0);
                addDrawableChild(ButtonWidget.builder(label, b -> {}).dimensions(x, y, lw, 20).build());
                addDrawableChild(ButtonWidget.builder(Text.literal("-"), b -> {
                    ns.value = Math.max(ns.min, round(ns.value - step)); rebuild();
                }).dimensions(x + lw + 2, y, sw, 20).build());
                addDrawableChild(ButtonWidget.builder(Text.literal("+"), b -> {
                    ns.value = Math.min(ns.max, round(ns.value + step)); rebuild();
                }).dimensions(x + lw + 2 + sw, y, sw, 20).build());
            }
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("Back"), b -> { open = null; rebuild(); })
            .dimensions(width / 2 - 40, height - 26, 80, 20).build());
    }

    private static double round(double d) { return Math.round(d * 100.0) / 100.0; }

    private static String value(Setting s) {
        if (s instanceof Setting.Bool b) return b.value ? "ON" : "OFF";
        if (s instanceof Setting.Num n) return String.valueOf(round(n.value));
        if (s instanceof Setting.Mode m) return m.value;
        return s.display();
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        String title = open == null ? "Nexus" : open.name;
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, 8, 0xFF55FFFF);
    }
}

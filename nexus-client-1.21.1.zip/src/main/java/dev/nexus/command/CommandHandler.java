package dev.nexus.command;

import dev.nexus.NexusClient;
import dev.nexus.module.Module;
import dev.nexus.module.ModuleManager;
import dev.nexus.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;

public class CommandHandler {
    /** Set by ".gui"; the menu opens on the next tick (the chat screen closes right after sending). */
    public static boolean openGui;

    /** Returns true if the message was a client command (and must not be sent to the server). */
    public static boolean handle(String msg) {
        if (!msg.startsWith(NexusClient.PREFIX)) return false;
        String[] a = msg.substring(NexusClient.PREFIX.length()).trim().split("\\s+");
        if (a.length == 0 || a[0].isEmpty()) { help(); return true; }

        switch (a[0].toLowerCase()) {
            case "help" -> help();
            case "gui", "menu" -> openGui = true;
            case "list" -> {
                for (Module m : ModuleManager.modules)
                    say((m.isEnabled() ? "§a" : "§7") + m.name + " §8[" + m.category + "]");
            }
            case "t", "toggle" -> {
                Module m = a.length > 1 ? ModuleManager.get(a[1]) : null;
                if (m == null) { say("§cModule not found."); break; }
                m.toggle();
                say(m.name + (m.isEnabled() ? " §aON" : " §cOFF"));
            }
            case "set" -> {
                Module m = a.length > 1 ? ModuleManager.get(a[1]) : null;
                if (m == null) { say("§cModule not found."); break; }
                if (a.length == 2) {
                    for (Setting s : m.settings) say("§7" + s.name + ": §f" + s.display());
                    break;
                }
                Setting s = m.getSetting(a[2]);
                if (s == null) { say("§cSetting not found."); break; }
                if (a.length < 4) { say("§7" + s.name + ": §f" + s.display()); break; }
                say(s.parse(a[3]) ? "§a" + s.name + " = " + a[3] : "§cInvalid value.");
            }
            case "bind" -> {
                Module m = a.length > 1 ? ModuleManager.get(a[1]) : null;
                if (m == null || a.length < 3) { say("§cUsage: .bind <module> <key|none>"); break; }
                if (a[2].equalsIgnoreCase("none")) { m.key = -1; say("Unbound " + m.name); break; }
                try {
                    m.key = InputUtil.fromTranslationKey("key.keyboard." + a[2].toLowerCase()).getCode();
                    say(m.name + " bound to " + a[2].toUpperCase());
                } catch (IllegalArgumentException e) { say("§cUnknown key."); }
            }
            default -> say("§cUnknown command. Try .help");
        }
        return true;
    }

    private static void help() {
        say("§b.gui §7- open menu (or Right Shift)");
        say("§b.list §7- modules");
        say("§b.t <module> §7- toggle");
        say("§b.set <module> [setting] [value] §7- settings");
        say("§b.bind <module> <key|none>");
    }

    private static void say(String s) {
        var p = MinecraftClient.getInstance().player;
        if (p != null) p.sendMessage(Text.literal("§8[§b" + NexusClient.NAME + "§8] §r" + s), false);
    }
}

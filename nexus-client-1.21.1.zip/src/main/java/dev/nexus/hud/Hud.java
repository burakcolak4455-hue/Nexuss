package dev.nexus.hud;

import dev.nexus.NexusClient;
import dev.nexus.module.Module;
import dev.nexus.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

import java.util.Comparator;
import java.util.List;

public class Hud {
    public static void render(DrawContext ctx, RenderTickCounter tick) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;

        ctx.drawTextWithShadow(mc.textRenderer, NexusClient.NAME, 4, 4, 0xFF55FFFF);

        List<Module> on = ModuleManager.modules.stream()
            .filter(Module::isEnabled)
            .sorted(Comparator.comparingInt((Module m) -> mc.textRenderer.getWidth(m.name)).reversed())
            .toList();

        int y = 4;
        for (Module m : on) {
            int x = ctx.getScaledWindowWidth() - mc.textRenderer.getWidth(m.name) - 4;
            ctx.drawTextWithShadow(mc.textRenderer, m.name, x, y, 0xFF55FFFF);
            y += 10;
        }
    }
}

package dev.nexus;

import dev.nexus.command.CommandHandler;
import dev.nexus.hud.Hud;
import dev.nexus.module.ModuleManager;
import dev.nexus.gui.ModuleScreen;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;

public class NexusClient implements ClientModInitializer {
    public static final String NAME = "Nexus";
    public static final String PREFIX = ".";
    private static boolean guiKeyDown;

    @Override
    public void onInitializeClient() {
        // Modules are built once the game client exists.
        ClientLifecycleEvents.CLIENT_STARTED.register(client -> ModuleManager.init());
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            ModuleManager.tick();
            boolean down = client.getWindow() != null
                && InputUtil.isKeyPressed(client.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT);
            boolean pressed = down && !guiKeyDown && client.currentScreen == null && client.player != null;
            guiKeyDown = down;
            if (pressed || CommandHandler.openGui) {
                CommandHandler.openGui = false;
                client.setScreen(new ModuleScreen());
            }
        });
        // Chat commands (.t aura, .set aura range 4) - works fine on touch screens.
        ClientSendMessageEvents.ALLOW_CHAT.register(msg -> !CommandHandler.handle(msg));
        HudRenderCallback.EVENT.register(Hud::render);
    }
}
